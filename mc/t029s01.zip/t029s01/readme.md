[address]钱包地址
[token]discord账号的token
[channel]频道ID，多个频道用逗号分割
[msg]发送的内容信息
[proxy]代理ip，如果没有也可以不设置
[delay]循环发送间隔时间，单位是秒