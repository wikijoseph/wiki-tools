1.配置t.ini文件（延迟时间是从from随机到to）
[address]网站mint的钱包地址
[delay_from]延迟时间from
[delay_to]延迟时间to

2.配置chat.txt，每行为一条聊天话术

3. 配置token.txt
[TOKEN_A]聊天人A的token
[TOKEN_B]聊天人B的token
[CHANNEL]频道ID